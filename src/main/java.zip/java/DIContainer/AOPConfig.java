package DIContainer;

public class AOPConfig {
}
